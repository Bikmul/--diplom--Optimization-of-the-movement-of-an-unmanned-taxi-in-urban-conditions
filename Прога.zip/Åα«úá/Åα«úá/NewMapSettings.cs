﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PathFinding
{
    public partial class NewMapSettings : Form
    {
        public NewMapSettings()
        {
            InitializeComponent();
            
        }

        private void NewMapSettings_Load(object sender, EventArgs e)
        {

        }

    }
}
