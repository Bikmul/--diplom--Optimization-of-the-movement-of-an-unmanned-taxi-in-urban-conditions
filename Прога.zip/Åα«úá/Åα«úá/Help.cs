﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PathFinding
{
    public partial class Help : Form
    {
        string text;
        public Help()
        {
            InitializeComponent();
            label1.Text = "Всем привет!";
            text = "Данный проект является моим дипломным проектом\n" +
                "Программа предлагает три популярных алгоритма поиска пути,\n" +
                "включая А-звёздочку, которая объединяет алгоритмы Лучший-Первый и Дийкстры.\n" +
                "Эти алгоритмы разработаны для двумерных сетчатых карт, но могут быть\n" +
                " адаптированы для карт любой размерности.\n" +
                "TimeOut обеспечивает задержку для детального анализа алгоритмов.\n" +
                "Графический редактор позволяет создавать препятствия с определённой стоимостью прохождения.\n" +
                "накопленной стоимостью пути, извлечённые из списка.\n" +
                "Созданную карту можно сохранить в файл и загрузить обратно,\n" +
                "используя правую кнопку мыши для навигации по карте.\n" +
                "Если возникли какие либо вапросы по программе.\n " +
                "Обращаться по почте Bikmullin24@mail.ru.\n" +
                "Амир Бикмуллин 4414\n" +
                "Казанский национальный исследовательский технический университет имени А.Н.Туполева";
            label2.Text = text;
        }

        private void Help_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }

        private void Close_btn_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private void Help_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
